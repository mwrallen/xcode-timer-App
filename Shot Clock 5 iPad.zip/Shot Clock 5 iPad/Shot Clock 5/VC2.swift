//
//  VC2.swift
//  Shot Clock 5
//
//  Created by Marcus Allen on 06/07/2022.
//

import UIKit
import Foundation
import SwiftUI


class VC2: UIViewController {
    
    var MatchTimer = Timer()
    var TimerDisplayed = 0
    
    
    
    
    
    
    
    override func viewDidLoad() {
        
    }
    
}
