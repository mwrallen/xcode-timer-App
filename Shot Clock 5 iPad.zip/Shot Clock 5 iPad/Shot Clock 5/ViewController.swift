//
//  ViewController.swift
//  Shot Clock 5
//
//  Created by Marcus Allen on 16/03/2022.
//

import UIKit
import AVFoundation
import SwiftUI
import ClockKit

class ViewController: UIViewController, UITextFieldDelegate{

    var seconds = 30
    var timer = Timer()
    var audioPlayer = AVAudioPlayer()
    var isPlaying = false
    var matchtimer = Timer()

    
    @IBOutlet weak var matchclocktimer: UILabel!
    
    @IBOutlet weak var label: UILabel!
    
    @IBOutlet weak var sliderOutlet: UISlider!
    @IBAction func slider(_ sender: UISlider)
    {seconds = Int(sender.value)
        label.text = String(seconds)}
    
    @IBAction func name2(_ sender: UITextField)
    {sender.resignFirstResponder()}
    
    @IBAction func name1(_ sender: UITextField)
    {sender.resignFirstResponder()}
    
    @IBAction func score2(_ sender: UITextField)
    {sender.resignFirstResponder()}
    
    @IBAction func score1(_ sender: UITextField)
    {sender.resignFirstResponder()}
    
    @IBOutlet weak var startOutlet: UIButton!
    @IBAction func start(_ sender: Any)
    {timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(ViewController.counter), userInfo: nil, repeats: true)
        sliderOutlet.isHidden = true
        startOutlet.isHidden = true}
    @IBOutlet weak var matchstartOutlet: UIButton!
    @IBAction func matchStart(_ sender: Any)
    {matchtimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(ViewController.counter), userInfo: nil, repeats: true)    }
    
    
    @objc func counter()
    {seconds -= 1
        label.text = String(seconds) + ""
        matchclocktimer.text = String(seconds) + ""
        if (seconds == 0)
        {timer.invalidate()}
        
        if (seconds == 6)
        {
            do {}
            sliderOutlet.isHidden = false
            startOutlet.isHidden = false
            audioPlayer.play()}}
    
    @IBAction func EXT2(_ sender: UIButton) {seconds += 15}
    @IBAction func ext2pressed(_ sender: UIButton)
    {sender.backgroundColor = sender.backgroundColor == UIColor.red ? UIColor.clear : UIColor.red}
    
    @IBAction func EXT1(_ sender: UIButton) {seconds += 15}
    @IBAction func ext1pressed(_ sender: UIButton)
    {sender.backgroundColor = sender.backgroundColor == UIColor.red ? UIColor.clear : UIColor.red}
    @IBAction func ext1resetaudio(_ sender: Any)
    {audioPlayer.stop()
        audioPlayer.currentTime = 0
        isPlaying = false}
    @IBAction func ext2resetaudio(_ sender: Any)
    {audioPlayer.stop()
        audioPlayer.currentTime = 0
        isPlaying = false}
    
    @IBOutlet weak var stop15Outlet: UIButton!
    @IBAction func stop15(_ sender: Any)
    {timer.invalidate()
        seconds = 15
        sliderOutlet.setValue(15 , animated: true)
        label.text = "15"
        audioPlayer.stop()
        sliderOutlet.isHidden = false
        startOutlet.isHidden = false}
    
    @IBAction func stop15resetaudio(_ sender: Any)
    {audioPlayer.stop()
        audioPlayer.currentTime = 0
        isPlaying = false}
    
    @IBOutlet weak var stopOutlet: UIButton!
    @IBAction func stop(_ sender: Any)
    {timer.invalidate()
        seconds = 30
        sliderOutlet.setValue(30 , animated: true)
        label.text = "30"
        audioPlayer.stop()
        sliderOutlet.isHidden = false
        startOutlet.isHidden = false}
   
    @IBAction func stopresetaudio(_ sender: Any)
    {audioPlayer.stop()
        audioPlayer.currentTime = 0
        isPlaying = false}
    
    override func viewDidLoad()
    {super.viewDidLoad()
        do
        {let audioPath = Bundle.main.path(forResource: "3", ofType: ".mp3")
            try audioPlayer = AVAudioPlayer(contentsOf: URL(fileURLWithPath: audioPath!))}
        catch {
            //ERROR
            
        }
    }
}


